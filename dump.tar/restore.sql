--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.4
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE trainingcenterapp;
--
-- Name: trainingcenterapp; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE trainingcenterapp WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'Polish_Poland.1250' LC_CTYPE = 'Polish_Poland.1250';


ALTER DATABASE trainingcenterapp OWNER TO postgres;

\connect trainingcenterapp

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: custom_movement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_movement (
    id bigint NOT NULL,
    user_id bigint
);


ALTER TABLE public.custom_movement OWNER TO postgres;

--
-- Name: custom_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.custom_record (
    id bigint NOT NULL,
    description character varying(255) NOT NULL,
    set_date date NOT NULL,
    value double precision NOT NULL
);


ALTER TABLE public.custom_record OWNER TO postgres;

--
-- Name: custom_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.custom_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.custom_record_id_seq OWNER TO postgres;

--
-- Name: custom_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.custom_record_id_seq OWNED BY public.custom_record.id;


--
-- Name: endurance_exercises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endurance_exercises (
    distance bytea,
    distance_unit character varying(255),
    hearth_rate integer NOT NULL,
    vo2max_percentage integer NOT NULL,
    "time" bytea,
    time_unit character varying(255),
    id bigint NOT NULL,
    training_session_id bigint
);


ALTER TABLE public.endurance_exercises OWNER TO postgres;

--
-- Name: endurance_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endurance_record (
    id bigint NOT NULL,
    distance integer NOT NULL,
    distance_unit character varying(255) NOT NULL,
    exercise_name character varying(255) NOT NULL,
    set_date date,
    "time" integer NOT NULL,
    time_unit character varying(255) NOT NULL,
    CONSTRAINT endurance_record_distance_check CHECK (((distance >= 0) AND (distance <= 10000))),
    CONSTRAINT endurance_record_time_check CHECK ((("time" <= 1000) AND ("time" >= 0)))
);


ALTER TABLE public.endurance_record OWNER TO postgres;

--
-- Name: endurance_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endurance_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endurance_record_id_seq OWNER TO postgres;

--
-- Name: endurance_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endurance_record_id_seq OWNED BY public.endurance_record.id;


--
-- Name: exercisable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercisable (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.exercisable OWNER TO postgres;

--
-- Name: exercisable_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exercisable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercisable_id_seq OWNER TO postgres;

--
-- Name: exercisable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exercisable_id_seq OWNED BY public.exercisable.id;


--
-- Name: exercise; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.exercise (
    id bigint NOT NULL,
    sets integer NOT NULL,
    exercisable_id bigint
);


ALTER TABLE public.exercise OWNER TO postgres;

--
-- Name: exercise_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.exercise_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.exercise_id_seq OWNER TO postgres;

--
-- Name: exercise_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.exercise_id_seq OWNED BY public.exercise.id;


--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id bigint NOT NULL,
    file_url character varying(255)
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: key_technique_element; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.key_technique_element (
    id bigint NOT NULL,
    content character varying(255)
);


ALTER TABLE public.key_technique_element OWNER TO postgres;

--
-- Name: key_technique_element_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.key_technique_element_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.key_technique_element_id_seq OWNER TO postgres;

--
-- Name: key_technique_element_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.key_technique_element_id_seq OWNED BY public.key_technique_element.id;


--
-- Name: movement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movement (
    id bigint NOT NULL
);


ALTER TABLE public.movement OWNER TO postgres;

--
-- Name: movement_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movement_images (
    movement_id bigint NOT NULL,
    images_id bigint NOT NULL
);


ALTER TABLE public.movement_images OWNER TO postgres;

--
-- Name: movement_muscles_involved; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.movement_muscles_involved (
    movement_id bigint NOT NULL,
    muscles_involved_id bigint NOT NULL
);


ALTER TABLE public.movement_muscles_involved OWNER TO postgres;

--
-- Name: muscles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.muscles (
    id bigint NOT NULL,
    description character varying(500),
    name character varying(48)
);


ALTER TABLE public.muscles OWNER TO postgres;

--
-- Name: muscles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.muscles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.muscles_id_seq OWNER TO postgres;

--
-- Name: muscles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.muscles_id_seq OWNED BY public.muscles.id;


--
-- Name: muscles_images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.muscles_images (
    muscles_id bigint NOT NULL,
    images_id bigint NOT NULL
);


ALTER TABLE public.muscles_images OWNER TO postgres;

--
-- Name: pace; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pace (
    id bigint NOT NULL,
    holding_down integer NOT NULL,
    holding_up integer NOT NULL,
    lowering integer NOT NULL,
    name character varying(255),
    raising integer NOT NULL
);


ALTER TABLE public.pace OWNER TO postgres;

--
-- Name: pace_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pace_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pace_id_seq OWNER TO postgres;

--
-- Name: pace_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pace_id_seq OWNED BY public.pace.id;


--
-- Name: personal_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_records (
    id bigint NOT NULL
);


ALTER TABLE public.personal_records OWNER TO postgres;

--
-- Name: personal_records_custom_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_records_custom_records (
    personal_records_id bigint NOT NULL,
    custom_records_id bigint NOT NULL
);


ALTER TABLE public.personal_records_custom_records OWNER TO postgres;

--
-- Name: personal_records_endurance_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_records_endurance_records (
    personal_records_id bigint NOT NULL,
    endurance_records_id bigint NOT NULL
);


ALTER TABLE public.personal_records_endurance_records OWNER TO postgres;

--
-- Name: personal_records_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_records_id_seq OWNER TO postgres;

--
-- Name: personal_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_records_id_seq OWNED BY public.personal_records.id;


--
-- Name: personal_records_strength_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_records_strength_records (
    personal_records_id bigint NOT NULL,
    strength_records_id bigint NOT NULL
);


ALTER TABLE public.personal_records_strength_records OWNER TO postgres;

--
-- Name: priorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.priorities (
    id bigint NOT NULL,
    details character varying(255),
    name character varying(255),
    training_plan_id bigint
);


ALTER TABLE public.priorities OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.priorities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.priorities_id_seq OWNER TO postgres;

--
-- Name: priorities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.priorities_id_seq OWNED BY public.priorities.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    name character varying(255)
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: strength_exercises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strength_exercises (
    repetition_unit character varying(255),
    reps bytea,
    reps_in_reserve integer,
    weight_unit character varying(255),
    weights bytea,
    id bigint NOT NULL,
    pace_id bigint,
    training_session_id bigint
);


ALTER TABLE public.strength_exercises OWNER TO postgres;

--
-- Name: strength_exercises_key_technique_elements; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strength_exercises_key_technique_elements (
    strength_exercises_id bigint NOT NULL,
    key_technique_elements_id bigint NOT NULL
);


ALTER TABLE public.strength_exercises_key_technique_elements OWNER TO postgres;

--
-- Name: strength_record; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.strength_record (
    id bigint NOT NULL,
    exercise_name character varying(255) NOT NULL,
    repetition integer NOT NULL,
    repetition_unit character varying(255) NOT NULL,
    set_date date,
    weight integer NOT NULL,
    weight_unit character varying(255) NOT NULL,
    CONSTRAINT strength_record_repetition_check CHECK (((repetition <= 1000) AND (repetition >= 0))),
    CONSTRAINT strength_record_weight_check CHECK (((weight >= '-30'::integer) AND (weight <= 500)))
);


ALTER TABLE public.strength_record OWNER TO postgres;

--
-- Name: strength_record_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.strength_record_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.strength_record_id_seq OWNER TO postgres;

--
-- Name: strength_record_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.strength_record_id_seq OWNED BY public.strength_record.id;


--
-- Name: test_class; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_class (
    chuj_id bigint NOT NULL
);


ALTER TABLE public.test_class OWNER TO postgres;

--
-- Name: training_plans; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_plans (
    id bigint NOT NULL,
    description character varying(255),
    difficulty character varying(255),
    end_date date,
    name character varying(255),
    number_of_executed_trainings integer NOT NULL,
    number_of_planned_trainings integer NOT NULL,
    start_date date,
    user_id bigint
);


ALTER TABLE public.training_plans OWNER TO postgres;

--
-- Name: training_plans_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.training_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_plans_id_seq OWNER TO postgres;

--
-- Name: training_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.training_plans_id_seq OWNED BY public.training_plans.id;


--
-- Name: training_plans_priorities; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_plans_priorities (
    training_plans_id bigint NOT NULL,
    priorities_id bigint NOT NULL
);


ALTER TABLE public.training_plans_priorities OWNER TO postgres;

--
-- Name: training_plans_training_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_plans_training_sessions (
    training_plans_id bigint NOT NULL,
    training_sessions_id bigint NOT NULL
);


ALTER TABLE public.training_plans_training_sessions OWNER TO postgres;

--
-- Name: training_sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_sessions (
    id bigint NOT NULL,
    date date,
    day_of_week character varying(255),
    difficulty character varying(255),
    end_time time without time zone,
    name character varying(255),
    notes character varying(255),
    start_time time without time zone,
    training_duration time without time zone,
    training_plan_id bigint
);


ALTER TABLE public.training_sessions OWNER TO postgres;

--
-- Name: training_sessions_exercises; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.training_sessions_exercises (
    training_sessions_id bigint NOT NULL,
    exercises_id bigint NOT NULL
);


ALTER TABLE public.training_sessions_exercises OWNER TO postgres;

--
-- Name: training_sessions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.training_sessions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.training_sessions_id_seq OWNER TO postgres;

--
-- Name: training_sessions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.training_sessions_id_seq OWNED BY public.training_sessions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying(255),
    password character varying(255),
    age integer NOT NULL,
    body_weight_unit character varying(255),
    height double precision NOT NULL,
    height_unit character varying(255),
    sex character varying(255),
    weight double precision NOT NULL,
    username character varying(255),
    image_id bigint,
    personal_records_id bigint
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_roles (
    users_id bigint NOT NULL,
    roles_id bigint NOT NULL
);


ALTER TABLE public.users_roles OWNER TO postgres;

--
-- Name: custom_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_record ALTER COLUMN id SET DEFAULT nextval('public.custom_record_id_seq'::regclass);


--
-- Name: endurance_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endurance_record ALTER COLUMN id SET DEFAULT nextval('public.endurance_record_id_seq'::regclass);


--
-- Name: exercisable id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercisable ALTER COLUMN id SET DEFAULT nextval('public.exercisable_id_seq'::regclass);


--
-- Name: exercise id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise ALTER COLUMN id SET DEFAULT nextval('public.exercise_id_seq'::regclass);


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: key_technique_element id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.key_technique_element ALTER COLUMN id SET DEFAULT nextval('public.key_technique_element_id_seq'::regclass);


--
-- Name: muscles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.muscles ALTER COLUMN id SET DEFAULT nextval('public.muscles_id_seq'::regclass);


--
-- Name: pace id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pace ALTER COLUMN id SET DEFAULT nextval('public.pace_id_seq'::regclass);


--
-- Name: personal_records id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records ALTER COLUMN id SET DEFAULT nextval('public.personal_records_id_seq'::regclass);


--
-- Name: priorities id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities ALTER COLUMN id SET DEFAULT nextval('public.priorities_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: strength_record id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_record ALTER COLUMN id SET DEFAULT nextval('public.strength_record_id_seq'::regclass);


--
-- Name: training_plans id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans ALTER COLUMN id SET DEFAULT nextval('public.training_plans_id_seq'::regclass);


--
-- Name: training_sessions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions ALTER COLUMN id SET DEFAULT nextval('public.training_sessions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: custom_movement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_movement (id, user_id) FROM stdin;
\.
COPY public.custom_movement (id, user_id) FROM '$$PATH$$/3085.dat';

--
-- Data for Name: custom_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.custom_record (id, description, set_date, value) FROM stdin;
\.
COPY public.custom_record (id, description, set_date, value) FROM '$$PATH$$/3087.dat';

--
-- Data for Name: endurance_exercises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endurance_exercises (distance, distance_unit, hearth_rate, vo2max_percentage, "time", time_unit, id, training_session_id) FROM stdin;
\.
COPY public.endurance_exercises (distance, distance_unit, hearth_rate, vo2max_percentage, "time", time_unit, id, training_session_id) FROM '$$PATH$$/3088.dat';

--
-- Data for Name: endurance_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endurance_record (id, distance, distance_unit, exercise_name, set_date, "time", time_unit) FROM stdin;
\.
COPY public.endurance_record (id, distance, distance_unit, exercise_name, set_date, "time", time_unit) FROM '$$PATH$$/3090.dat';

--
-- Data for Name: exercisable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercisable (id, name) FROM stdin;
\.
COPY public.exercisable (id, name) FROM '$$PATH$$/3092.dat';

--
-- Data for Name: exercise; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.exercise (id, sets, exercisable_id) FROM stdin;
\.
COPY public.exercise (id, sets, exercisable_id) FROM '$$PATH$$/3094.dat';

--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, file_url) FROM stdin;
\.
COPY public.images (id, file_url) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: key_technique_element; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.key_technique_element (id, content) FROM stdin;
\.
COPY public.key_technique_element (id, content) FROM '$$PATH$$/3098.dat';

--
-- Data for Name: movement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movement (id) FROM stdin;
\.
COPY public.movement (id) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: movement_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movement_images (movement_id, images_id) FROM stdin;
\.
COPY public.movement_images (movement_id, images_id) FROM '$$PATH$$/3100.dat';

--
-- Data for Name: movement_muscles_involved; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.movement_muscles_involved (movement_id, muscles_involved_id) FROM stdin;
\.
COPY public.movement_muscles_involved (movement_id, muscles_involved_id) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: muscles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.muscles (id, description, name) FROM stdin;
\.
COPY public.muscles (id, description, name) FROM '$$PATH$$/3103.dat';

--
-- Data for Name: muscles_images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.muscles_images (muscles_id, images_id) FROM stdin;
\.
COPY public.muscles_images (muscles_id, images_id) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: pace; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pace (id, holding_down, holding_up, lowering, name, raising) FROM stdin;
\.
COPY public.pace (id, holding_down, holding_up, lowering, name, raising) FROM '$$PATH$$/3106.dat';

--
-- Data for Name: personal_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_records (id) FROM stdin;
\.
COPY public.personal_records (id) FROM '$$PATH$$/3108.dat';

--
-- Data for Name: personal_records_custom_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_records_custom_records (personal_records_id, custom_records_id) FROM stdin;
\.
COPY public.personal_records_custom_records (personal_records_id, custom_records_id) FROM '$$PATH$$/3109.dat';

--
-- Data for Name: personal_records_endurance_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_records_endurance_records (personal_records_id, endurance_records_id) FROM stdin;
\.
COPY public.personal_records_endurance_records (personal_records_id, endurance_records_id) FROM '$$PATH$$/3110.dat';

--
-- Data for Name: personal_records_strength_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_records_strength_records (personal_records_id, strength_records_id) FROM stdin;
\.
COPY public.personal_records_strength_records (personal_records_id, strength_records_id) FROM '$$PATH$$/3111.dat';

--
-- Data for Name: priorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.priorities (id, details, name, training_plan_id) FROM stdin;
\.
COPY public.priorities (id, details, name, training_plan_id) FROM '$$PATH$$/3113.dat';

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, name) FROM stdin;
\.
COPY public.roles (id, name) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: strength_exercises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strength_exercises (repetition_unit, reps, reps_in_reserve, weight_unit, weights, id, pace_id, training_session_id) FROM stdin;
\.
COPY public.strength_exercises (repetition_unit, reps, reps_in_reserve, weight_unit, weights, id, pace_id, training_session_id) FROM '$$PATH$$/3116.dat';

--
-- Data for Name: strength_exercises_key_technique_elements; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strength_exercises_key_technique_elements (strength_exercises_id, key_technique_elements_id) FROM stdin;
\.
COPY public.strength_exercises_key_technique_elements (strength_exercises_id, key_technique_elements_id) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: strength_record; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.strength_record (id, exercise_name, repetition, repetition_unit, set_date, weight, weight_unit) FROM stdin;
\.
COPY public.strength_record (id, exercise_name, repetition, repetition_unit, set_date, weight, weight_unit) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: test_class; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_class (chuj_id) FROM stdin;
\.
COPY public.test_class (chuj_id) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: training_plans; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_plans (id, description, difficulty, end_date, name, number_of_executed_trainings, number_of_planned_trainings, start_date, user_id) FROM stdin;
\.
COPY public.training_plans (id, description, difficulty, end_date, name, number_of_executed_trainings, number_of_planned_trainings, start_date, user_id) FROM '$$PATH$$/3128.dat';

--
-- Data for Name: training_plans_priorities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_plans_priorities (training_plans_id, priorities_id) FROM stdin;
\.
COPY public.training_plans_priorities (training_plans_id, priorities_id) FROM '$$PATH$$/3129.dat';

--
-- Data for Name: training_plans_training_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_plans_training_sessions (training_plans_id, training_sessions_id) FROM stdin;
\.
COPY public.training_plans_training_sessions (training_plans_id, training_sessions_id) FROM '$$PATH$$/3130.dat';

--
-- Data for Name: training_sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_sessions (id, date, day_of_week, difficulty, end_time, name, notes, start_time, training_duration, training_plan_id) FROM stdin;
\.
COPY public.training_sessions (id, date, day_of_week, difficulty, end_time, name, notes, start_time, training_duration, training_plan_id) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: training_sessions_exercises; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.training_sessions_exercises (training_sessions_id, exercises_id) FROM stdin;
\.
COPY public.training_sessions_exercises (training_sessions_id, exercises_id) FROM '$$PATH$$/3123.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, password, age, body_weight_unit, height, height_unit, sex, weight, username, image_id, personal_records_id) FROM stdin;
\.
COPY public.users (id, email, password, age, body_weight_unit, height, height_unit, sex, weight, username, image_id, personal_records_id) FROM '$$PATH$$/3125.dat';

--
-- Data for Name: users_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_roles (users_id, roles_id) FROM stdin;
\.
COPY public.users_roles (users_id, roles_id) FROM '$$PATH$$/3126.dat';

--
-- Name: custom_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.custom_record_id_seq', 1, false);


--
-- Name: endurance_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endurance_record_id_seq', 1, false);


--
-- Name: exercisable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exercisable_id_seq', 3, true);


--
-- Name: exercise_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.exercise_id_seq', 4, true);


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 3, true);


--
-- Name: key_technique_element_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.key_technique_element_id_seq', 1, false);


--
-- Name: muscles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.muscles_id_seq', 3, true);


--
-- Name: pace_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pace_id_seq', 1, false);


--
-- Name: personal_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_records_id_seq', 1, false);


--
-- Name: priorities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.priorities_id_seq', 3, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: strength_record_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.strength_record_id_seq', 1, false);


--
-- Name: training_plans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.training_plans_id_seq', 7, true);


--
-- Name: training_sessions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.training_sessions_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 6, true);


--
-- Name: custom_movement custom_movement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_movement
    ADD CONSTRAINT custom_movement_pkey PRIMARY KEY (id);


--
-- Name: custom_record custom_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_record
    ADD CONSTRAINT custom_record_pkey PRIMARY KEY (id);


--
-- Name: endurance_exercises endurance_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endurance_exercises
    ADD CONSTRAINT endurance_exercises_pkey PRIMARY KEY (id);


--
-- Name: endurance_record endurance_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endurance_record
    ADD CONSTRAINT endurance_record_pkey PRIMARY KEY (id);


--
-- Name: exercisable exercisable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercisable
    ADD CONSTRAINT exercisable_pkey PRIMARY KEY (id);


--
-- Name: exercise exercise_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT exercise_pkey PRIMARY KEY (id);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: key_technique_element key_technique_element_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.key_technique_element
    ADD CONSTRAINT key_technique_element_pkey PRIMARY KEY (id);


--
-- Name: movement movement_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement
    ADD CONSTRAINT movement_pkey PRIMARY KEY (id);


--
-- Name: muscles muscles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.muscles
    ADD CONSTRAINT muscles_pkey PRIMARY KEY (id);


--
-- Name: pace pace_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pace
    ADD CONSTRAINT pace_pkey PRIMARY KEY (id);


--
-- Name: personal_records personal_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records
    ADD CONSTRAINT personal_records_pkey PRIMARY KEY (id);


--
-- Name: priorities priorities_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT priorities_pkey PRIMARY KEY (id);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: strength_exercises strength_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises
    ADD CONSTRAINT strength_exercises_pkey PRIMARY KEY (id);


--
-- Name: strength_record strength_record_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_record
    ADD CONSTRAINT strength_record_pkey PRIMARY KEY (id);


--
-- Name: test_class test_class_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.test_class
    ADD CONSTRAINT test_class_pkey PRIMARY KEY (chuj_id);


--
-- Name: training_plans training_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT training_plans_pkey PRIMARY KEY (id);


--
-- Name: training_sessions training_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions
    ADD CONSTRAINT training_sessions_pkey PRIMARY KEY (id);


--
-- Name: personal_records_endurance_records uk_c15jgev6gpshpeljc4rti7u9y; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_endurance_records
    ADD CONSTRAINT uk_c15jgev6gpshpeljc4rti7u9y UNIQUE (endurance_records_id);


--
-- Name: training_sessions_exercises uk_coi3pr4pc4b84w55ptahs090b; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions_exercises
    ADD CONSTRAINT uk_coi3pr4pc4b84w55ptahs090b UNIQUE (exercises_id);


--
-- Name: strength_exercises_key_technique_elements uk_d4by730rl1u7xhedjkrsnyskt; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises_key_technique_elements
    ADD CONSTRAINT uk_d4by730rl1u7xhedjkrsnyskt UNIQUE (key_technique_elements_id);


--
-- Name: personal_records_strength_records uk_dcpev2xyjnr4kgtkyutqth5pj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_strength_records
    ADD CONSTRAINT uk_dcpev2xyjnr4kgtkyutqth5pj UNIQUE (strength_records_id);


--
-- Name: personal_records_custom_records uk_fsoaao1bhbt72t5a88dhmappe; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_custom_records
    ADD CONSTRAINT uk_fsoaao1bhbt72t5a88dhmappe UNIQUE (custom_records_id);


--
-- Name: movement_muscles_involved uk_jteyisto1j8et0rqc2qlujunn; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_muscles_involved
    ADD CONSTRAINT uk_jteyisto1j8et0rqc2qlujunn UNIQUE (muscles_involved_id);


--
-- Name: muscles_images uk_n2ftnrq4ca7pphts5kgsf9tvw; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.muscles_images
    ADD CONSTRAINT uk_n2ftnrq4ca7pphts5kgsf9tvw UNIQUE (images_id);


--
-- Name: training_plans_priorities uk_rgrmsbbldyfxfm46yg0l6jwym; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_priorities
    ADD CONSTRAINT uk_rgrmsbbldyfxfm46yg0l6jwym UNIQUE (priorities_id);


--
-- Name: training_plans_training_sessions uk_seuexe1r9g79ehgi5i3eekpux; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_training_sessions
    ADD CONSTRAINT uk_seuexe1r9g79ehgi5i3eekpux UNIQUE (training_sessions_id);


--
-- Name: movement_images uk_sp2u6xt4mck88mq6bf8o4yh3; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_images
    ADD CONSTRAINT uk_sp2u6xt4mck88mq6bf8o4yh3 UNIQUE (images_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users fk17herqt2to4hyl5q5r5ogbxk9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fk17herqt2to4hyl5q5r5ogbxk9 FOREIGN KEY (image_id) REFERENCES public.images(id);


--
-- Name: endurance_exercises fk27kdkyw6bibj2tpatioy39ibj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endurance_exercises
    ADD CONSTRAINT fk27kdkyw6bibj2tpatioy39ibj FOREIGN KEY (id) REFERENCES public.exercise(id);


--
-- Name: movement_muscles_involved fk2c9v7wiv6up9mc0i8xobn9m53; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_muscles_involved
    ADD CONSTRAINT fk2c9v7wiv6up9mc0i8xobn9m53 FOREIGN KEY (muscles_involved_id) REFERENCES public.muscles(id);


--
-- Name: personal_records_strength_records fk3finfdlpep2efobiaj3y5i2u4; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_strength_records
    ADD CONSTRAINT fk3finfdlpep2efobiaj3y5i2u4 FOREIGN KEY (strength_records_id) REFERENCES public.strength_record(id);


--
-- Name: personal_records_custom_records fk4wxmn5v91hwwnb9r0hwqkxcqv; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_custom_records
    ADD CONSTRAINT fk4wxmn5v91hwwnb9r0hwqkxcqv FOREIGN KEY (custom_records_id) REFERENCES public.custom_record(id);


--
-- Name: personal_records_custom_records fk5yfja5s079e52o76rhfa5b6hw; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_custom_records
    ADD CONSTRAINT fk5yfja5s079e52o76rhfa5b6hw FOREIGN KEY (personal_records_id) REFERENCES public.personal_records(id);


--
-- Name: movement_images fk7d4ws0de6t6isjx7ikx1cwodc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_images
    ADD CONSTRAINT fk7d4ws0de6t6isjx7ikx1cwodc FOREIGN KEY (images_id) REFERENCES public.images(id);


--
-- Name: training_sessions_exercises fk8t6kagn56ry499i7n4myrp738; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions_exercises
    ADD CONSTRAINT fk8t6kagn56ry499i7n4myrp738 FOREIGN KEY (training_sessions_id) REFERENCES public.training_sessions(id);


--
-- Name: users_roles fka62j07k5mhgifpp955h37ponj; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT fka62j07k5mhgifpp955h37ponj FOREIGN KEY (roles_id) REFERENCES public.roles(id);


--
-- Name: training_plans_priorities fkaqplj65dvjg37a31j5cm8o7eh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_priorities
    ADD CONSTRAINT fkaqplj65dvjg37a31j5cm8o7eh FOREIGN KEY (priorities_id) REFERENCES public.priorities(id);


--
-- Name: movement fkbrmnnoxmrir43cdtba799o9l7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement
    ADD CONSTRAINT fkbrmnnoxmrir43cdtba799o9l7 FOREIGN KEY (id) REFERENCES public.exercisable(id);


--
-- Name: custom_movement fkbtgh00k33v08e35th80rplm9v; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_movement
    ADD CONSTRAINT fkbtgh00k33v08e35th80rplm9v FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: priorities fkchaur5xmmrd3roswlhkqr0cje; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.priorities
    ADD CONSTRAINT fkchaur5xmmrd3roswlhkqr0cje FOREIGN KEY (training_plan_id) REFERENCES public.training_plans(id);


--
-- Name: users fke5tv2vyqqm11m46c2agrd5i14; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fke5tv2vyqqm11m46c2agrd5i14 FOREIGN KEY (personal_records_id) REFERENCES public.personal_records(id);


--
-- Name: personal_records_strength_records fkf0mt23woxrhwo523wxy6702f3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_strength_records
    ADD CONSTRAINT fkf0mt23woxrhwo523wxy6702f3 FOREIGN KEY (personal_records_id) REFERENCES public.personal_records(id);


--
-- Name: training_plans fkfmh2q5ujep9t2ysd9eh75mto2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans
    ADD CONSTRAINT fkfmh2q5ujep9t2ysd9eh75mto2 FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: training_sessions_exercises fkg3r6axen1j63a11ovcujp0hb2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions_exercises
    ADD CONSTRAINT fkg3r6axen1j63a11ovcujp0hb2 FOREIGN KEY (exercises_id) REFERENCES public.exercise(id);


--
-- Name: endurance_exercises fki4t0vthme1cm0ad4qy83jmiyh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endurance_exercises
    ADD CONSTRAINT fki4t0vthme1cm0ad4qy83jmiyh FOREIGN KEY (training_session_id) REFERENCES public.training_sessions(id);


--
-- Name: muscles_images fkid756aomggthxji6kije0ooyq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.muscles_images
    ADD CONSTRAINT fkid756aomggthxji6kije0ooyq FOREIGN KEY (muscles_id) REFERENCES public.muscles(id);


--
-- Name: personal_records_endurance_records fkjo7i8if4qn9cljon9fle6w2mo; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_endurance_records
    ADD CONSTRAINT fkjo7i8if4qn9cljon9fle6w2mo FOREIGN KEY (personal_records_id) REFERENCES public.personal_records(id);


--
-- Name: strength_exercises_key_technique_elements fkjwh6xxwevg3cxkkbsfuh85637; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises_key_technique_elements
    ADD CONSTRAINT fkjwh6xxwevg3cxkkbsfuh85637 FOREIGN KEY (strength_exercises_id) REFERENCES public.strength_exercises(id);


--
-- Name: exercise fkkh6c3cudufkqmrc1o7n81vvk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.exercise
    ADD CONSTRAINT fkkh6c3cudufkqmrc1o7n81vvk2 FOREIGN KEY (exercisable_id) REFERENCES public.exercisable(id);


--
-- Name: training_plans_training_sessions fklyr4lfsnalww85tvs2mhfrade; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_training_sessions
    ADD CONSTRAINT fklyr4lfsnalww85tvs2mhfrade FOREIGN KEY (training_sessions_id) REFERENCES public.training_sessions(id);


--
-- Name: users_roles fkml90kef4w2jy7oxyqv742tsfc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_roles
    ADD CONSTRAINT fkml90kef4w2jy7oxyqv742tsfc FOREIGN KEY (users_id) REFERENCES public.users(id);


--
-- Name: training_sessions fkn3yveohwsptu62rlqg38rfsbr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_sessions
    ADD CONSTRAINT fkn3yveohwsptu62rlqg38rfsbr FOREIGN KEY (training_plan_id) REFERENCES public.training_plans(id);


--
-- Name: personal_records_endurance_records fknk4nrnajrbglbc5u5g22gnop7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_records_endurance_records
    ADD CONSTRAINT fknk4nrnajrbglbc5u5g22gnop7 FOREIGN KEY (endurance_records_id) REFERENCES public.endurance_record(id);


--
-- Name: custom_movement fkouadishyb16c9wlejt4bpsdcl; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.custom_movement
    ADD CONSTRAINT fkouadishyb16c9wlejt4bpsdcl FOREIGN KEY (id) REFERENCES public.exercisable(id);


--
-- Name: strength_exercises fkpg1eibq9y2xgjee0t02jwvl2f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises
    ADD CONSTRAINT fkpg1eibq9y2xgjee0t02jwvl2f FOREIGN KEY (id) REFERENCES public.exercise(id);


--
-- Name: muscles_images fkppb7mo72tuvg5hppq8nstlts3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.muscles_images
    ADD CONSTRAINT fkppb7mo72tuvg5hppq8nstlts3 FOREIGN KEY (images_id) REFERENCES public.images(id);


--
-- Name: movement_images fkqmtk3h30jqwljjcte260bkku3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_images
    ADD CONSTRAINT fkqmtk3h30jqwljjcte260bkku3 FOREIGN KEY (movement_id) REFERENCES public.movement(id);


--
-- Name: strength_exercises fkqwe3se4ku3s0hjj8y6m05b9r5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises
    ADD CONSTRAINT fkqwe3se4ku3s0hjj8y6m05b9r5 FOREIGN KEY (pace_id) REFERENCES public.pace(id);


--
-- Name: strength_exercises_key_technique_elements fkr1rjm8ws2d0ks7sbx0f0yfaaq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises_key_technique_elements
    ADD CONSTRAINT fkr1rjm8ws2d0ks7sbx0f0yfaaq FOREIGN KEY (key_technique_elements_id) REFERENCES public.key_technique_element(id);


--
-- Name: training_plans_priorities fkr5es05xisi2dgdbxnxawxevli; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_priorities
    ADD CONSTRAINT fkr5es05xisi2dgdbxnxawxevli FOREIGN KEY (training_plans_id) REFERENCES public.training_plans(id);


--
-- Name: strength_exercises fkrkqkyvf3xh9frc3qegxyavro8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.strength_exercises
    ADD CONSTRAINT fkrkqkyvf3xh9frc3qegxyavro8 FOREIGN KEY (training_session_id) REFERENCES public.training_sessions(id);


--
-- Name: training_plans_training_sessions fkrtsqjdb9l60lk43qmkgt74efl; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.training_plans_training_sessions
    ADD CONSTRAINT fkrtsqjdb9l60lk43qmkgt74efl FOREIGN KEY (training_plans_id) REFERENCES public.training_plans(id);


--
-- Name: movement_muscles_involved fkt3na1q7cl43316m5b07yey7oc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.movement_muscles_involved
    ADD CONSTRAINT fkt3na1q7cl43316m5b07yey7oc FOREIGN KEY (movement_id) REFERENCES public.movement(id);


--
-- PostgreSQL database dump complete
--

